export const initialState = {
  query: '',
  loading: false,
  messages: [],
};

export function reducer(state, action) {
  switch (action.type) {
    case 'SET_QUERY':
      return { ...state, query: action.payload };
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'ADD_MESSAGE':
      return { ...state, messages: [...state.messages, action.payload] };
    case 'UPDATE_LAST_MESSAGE': {
      const messages = [...state.messages];
      if (messages.length > 0) messages[messages.length - 1].text = action.payload;
      return { ...state, messages };
    }
    case 'EDIT_MESSAGE': {
      const messages = [...state.messages];
      if (messages[action.index]) messages[action.index] = { ...messages[action.index], text: action.text };
      return { ...state, messages };
    }
    case 'REMOVE_AFTER_INDEX':
      return { ...state, messages: state.messages.slice(0, action.index + 1) };
    default:
      return state;
  }
}
