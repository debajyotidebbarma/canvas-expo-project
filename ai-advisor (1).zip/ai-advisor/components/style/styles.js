import { StyleSheet, Platform } from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingTop: 8,
    marginTop: Platform.OS == 'android' ? 50 : 0,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0', 
  },
  headerText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  logo: {
    width: 32,
    height: 32,
    borderRadius: 16,
    marginRight: 8,
  },
  chatContainer: {
    flex: 1,
  },
  messageBubble: {
    maxWidth: '80%',
    borderRadius: 18,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginVertical: 4,
  },
  userBubble: {
    alignSelf: 'flex-end',
    backgroundColor: '#000',
  },
  aiBubble: {
    alignSelf: 'flex-start',
    backgroundColor: '#ececec',
  },
  userText: {
    color: '#fff',
  },
  aiText: {
    color: '#000',
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
    gap: 8,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  button: {
    backgroundColor: '#000',
    paddingHorizontal: 26,
    paddingVertical: 10,
    borderRadius: 20,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },

  // Edit controls

//   messageContainer: {
//   marginBottom: 12,
//   alignSelf: 'flex-start', // keeps alignment consistent
// },
editButton: {
  marginTop: 4,
  alignSelf: 'flex-end',
  paddingHorizontal: 8,
  paddingVertical: 4,
  borderRadius: 8,
  backgroundColor: '#d9d9d9',
},
  
  editButtonText: {
    fontSize: 12,
    color: '#000',
  },

  // Stop button
  stopButton: {
    marginTop: 6,
    alignSelf: 'flex-start',
    backgroundColor: '#ff4444',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  stopButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 12,
  },
});
