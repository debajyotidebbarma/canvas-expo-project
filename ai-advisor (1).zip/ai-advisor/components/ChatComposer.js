import React from 'react';
import { View, TextInput, TouchableOpacity, Text } from 'react-native';
import styles from './style/styles';

export default function ChatComposer({
  query,
  onChangeText,
  onSend,
  onStop,
  loading,
  editingIndex,
  insetsBottom,
}) {
  return (
    <View style={[styles.inputRow, { paddingBottom: insetsBottom }]}>
      <TextInput
        style={styles.input}
        placeholder={editingIndex !== null ? 'Edit your message…' : 'Type a message…'}
        value={query}
        onChangeText={onChangeText}
        editable
      />
      {loading ? (
        <TouchableOpacity style={[styles.button, { backgroundColor: 'red' }]} onPress={onStop}>
          <Text style={styles.buttonText}>Stop</Text>
        </TouchableOpacity>
      ) : (
        <TouchableOpacity style={styles.button} onPress={() => onSend(query)}>
          <Text style={styles.buttonText}>{editingIndex !== null ? 'Update' : 'Send'}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}
