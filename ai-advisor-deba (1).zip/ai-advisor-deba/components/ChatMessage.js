import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import styles from './style/styles';

export default function ChatMessage({ type, text, onEdit, index }) {
  const isUser = type === 'user';

  return (
    <View style={styles.messageContainer}>
      <View
        style={[
          styles.messageBubble,
          isUser ? styles.userBubble : styles.aiBubble,
        ]}
      >
        <Text style={isUser ? styles.userText : styles.aiText}>{text}</Text>
      </View>

      {isUser && typeof onEdit === 'function' && (
        <TouchableOpacity
          style={styles.editButton}
          onPress={() => onEdit(index)}
        >
          <Text style={styles.editButtonText}>Edit</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}
