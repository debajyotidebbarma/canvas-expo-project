import React from 'react';
import { View, Text, Image } from 'react-native';
import styles from './style/styles';

export default function Header({ logo }) {
  return (
    <View style={styles.header}>
      <Image source={logo} style={styles.logo} />
      <Text style={styles.headerText}>AI Advisor</Text>
    </View>
  );
}
