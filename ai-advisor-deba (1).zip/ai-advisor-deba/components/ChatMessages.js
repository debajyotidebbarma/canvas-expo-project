import React from 'react';
import { ScrollView } from 'react-native';
import ChatMessage from './ChatMessage';

export default function ChatMessages({ messages, scrollRef, onEdit, scrollToBottom }) {
  return (
    <ScrollView
      ref={scrollRef}
      contentContainerStyle={{ paddingBottom: 20 }}
      keyboardShouldPersistTaps="handled"
      onContentSizeChange={scrollToBottom}
    >
      {messages.map((msg, index) => (
        <ChatMessage
          key={index}
          type={msg.type}
          text={msg.text}
          index={index}
          onEdit={msg.type === 'user' ? onEdit : undefined}
        />
      ))}
    </ScrollView>
  );
}
