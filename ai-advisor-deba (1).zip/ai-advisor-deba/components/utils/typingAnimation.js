export function typeText(fullText, onUpdate, onComplete, delay = 20) {
  let i = 0;
  let stopped = false;
  let timeoutId;

  function tick() {
    if (stopped) {
      onComplete && onComplete();
      return;
    }

    if (i < fullText.length) {
      onUpdate(fullText.slice(0, i + 1));
      i += 1;
      timeoutId = setTimeout(tick, delay);
    } else {
      onComplete && onComplete();
    }
  }

  tick();

  return {
    stop: () => {
      stopped = true;
      if (timeoutId) clearTimeout(timeoutId);
    },
  };
}
