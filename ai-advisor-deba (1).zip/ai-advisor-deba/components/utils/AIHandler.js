import { typeText } from './typingAnimation';
import { PRODUCT_CATALOG } from '../../Data/product_catalog';

export async function getAIRecommendations({ queryText, dispatch, scrollToBottom, typingControllerRef }) {
  dispatch({ type: 'SET_LOADING', payload: true });

  const prompt = `
You are an expert AI Product Advisor. Your role is to assist users with helpful, friendly, and context-aware advice.

Below is a product catalog in JSON format:
${JSON.stringify(PRODUCT_CATALOG)}

A user has expressed the following input:
"${queryText}"

Your task is to behave like a real human advisor. Follow these guidelines:

1. **Understand user intent**:
   - If the user is asking for product advice, recommendations, or guidance, evaluate the catalog and suggest up to 3 suitable products.
   - If the user is expressing gratitude, greeting, or making unrelated comments (e.g., "thank you", "hello"), respond politely and naturally without suggesting products.

2. **When recommending products**:
   - Evaluate all products in the catalog.
   - Select the 3 most suitable products.
   - For each recommended product:
     - Provide the product name.
     - Give a short explanation describing why it is a good fit for the user's need (be specific).

3. **Tone and style**:
   - Always respond in a **friendly, conversational tone**, as a helpful human advisor.
   - Avoid unnecessary recommendations if the user’s input does not indicate interest.

Respond clearly and naturally, keeping the conversation engaging.
.
`;

  try {
    const response = await fetch(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-goog-api-key': 'AIzaSyDN3YuHjEFNsIUAqo8qrqTBcImKLZFKUPk',
        },
        body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
      }
    );

    const data = await response.json();
    const fullText = data?.candidates?.[0]?.content?.parts?.[0]?.text || 'No result';

    dispatch({ type: 'ADD_MESSAGE', payload: { text: '', type: 'ai' } });

    typingControllerRef.current = typeText(
      fullText,
      (partial) => {
        dispatch({ type: 'UPDATE_LAST_MESSAGE', payload: partial });
        scrollToBottom();
      },
      () => {
        dispatch({ type: 'SET_LOADING', payload: false });
        typingControllerRef.current = null;
      }
    );
  } catch (error) {
    console.error(error);
    dispatch({ type: 'ADD_MESSAGE', payload: { text: 'Something went wrong', type: 'ai' } });
    dispatch({ type: 'SET_LOADING', payload: false });
  }
}
